#ifndef HDL_GPIO_H
#define HDL_GPIO_H

#include "stm32f10x.h"

#define LED_CONTROL_PIN		(GPIO_Pin_0)
#define LED_PutVal(val)		(GPIO_WriteBit(GPIOA,LED_CONTROL_PIN,val))

#define LED_CONTROL_PIN1		(GPIO_Pin_1)
#define LED_PutVal1(val)		(GPIO_WriteBit(GPIOA,LED_CONTROL_PIN1,val))

#define BEEP_CONTROL_PIN		(GPIO_Pin_12)
#define BEEP_PutVal(val)		(GPIO_WriteBit(GPIOB,BEEP_CONTROL_PIN,val))





void fml_led_init(void);
void fml_key_init(void);


#endif

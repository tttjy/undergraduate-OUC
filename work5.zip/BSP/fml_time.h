#ifndef FML_TIME_H
#define FML_TIME_H

#include "stm32f10x.h"


void fml_delay_ms(uint16_t ms);



#endif

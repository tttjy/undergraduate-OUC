#include "stm32f10x.h"
#include "fml_gpio.h"
#include "fml_time.h"
#include "fml_usart.h"
#include "fml_motor.h"
#include "app_bluetooth.h"
#include "fml_ir.h"

int main(void)
{
	fml_led_init();
	fml_key_init();
	fml_usart_init();
	BluetoothInit();
	BluetoothConfig();
	fml_motor_init();
	//fml_motor_forward();
	fml_ir_init();
	printf("hello world\r\n");
	for(;;)
	{
		RemoteCtrlTask();
		UsartCtrlTask();
		BluetoothCtrlTask();	
	}
}




















